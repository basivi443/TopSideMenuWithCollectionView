# taby-segmented-control
Demo App on how to use UISegmentedControl to switch between child view controllers.
Also, styling it like a tab-bar.
Tested for Swift 2.0
