//
//  SecondTabViewController.swift
//  UISegmentedControlAsTabbarDemo
//
//  Created by Ahmed Abdurrahman on 9/16/15.
//  Copyright © 2015 A. Abdurrahman. All rights reserved.
//
import UIKit

class SecondTabViewController: UIViewController {
    
    var name  = String()
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print("Second VC will appear")
        print(name)
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        print("Second VC will disappear")
    }
}

class ThirdTabViewController: UIViewController {
    
    var name = String()
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print(name)
        print("ThirdTabViewController VC will appear")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        print("ThirdTabViewController VC will disappear")
    }
}
class ForthTabViewController: UIViewController {
    
    var name = String()
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print(name)
        print("ForthTabViewController VC will appear")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        print("ForthTabViewController VC will disappear")
    }
}
class FifthTabViewController: UIViewController {
    var name = String()
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print(name)
        print("FifthTabViewController VC will appear")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        print("FifthTabViewController VC will disappear")
    }
}
class SixTabViewController: UIViewController {
    var name = String()
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        print(name)
        print("SixTabViewController VC will appear")
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        print("SixTabViewController VC will disappear")
    }
}
