//
//  NamesCollectionViewCell.swift
//  UISegmentedControlAsTabbarDemo
//
//  Created by Basivi Reddy on 23/11/23.
//  Copyright © 2023 A. Abdurrahman. All rights reserved.
//

import UIKit

class NamesCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var nameLable: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

}
